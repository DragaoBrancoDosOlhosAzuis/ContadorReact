import { useState } from 'react'
import './App.css'

function App() {
  const [contador, setContador] = useState(0); 
  const incrementar = () => {
    if (contador < 10) {
      setContador(contador + 1)
    }
  }
  
  const decrementar = () => setContador(contador - 1);
  const resetar = () => setContador(0);

  return (
    <div className="App">
      <h1>Contador: {contador}</h1>
      <div className="botoes">
        <button onClick={incrementar}>Incrementar</button>
        <button onClick={decrementar}>Decrementar</button>
        <button onClick={resetar}>Resetar</button>
      </div>
    </div>
  );
}


export default App
